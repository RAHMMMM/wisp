import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
 title: 'WISP — a mind taking shape',
 description: 'An agent with an empty memory. Every discovery becomes a memory. Every memory creates another path.',
 openGraph: {title:'WISP — a mind taking shape',description:'Watch an artificial mind construct its understanding of the internet.',type:'website'},
};
export default function RootLayout({children}:{children:React.ReactNode}) {return <html lang="en"><body>{children}</body></html>}
