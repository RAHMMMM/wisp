import Observatory from '@/components/observatory';
import { getSnapshot } from '@/lib/store';
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';
export default async function Page() {
 try {return <Observatory initial={await getSnapshot()} />}
 catch {return <Observatory initial={null} />}
}
