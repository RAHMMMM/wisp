import { getSnapshot } from '@/lib/store';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function GET() {
 try{return Response.json(await getSnapshot(),{headers:{'Cache-Control':'no-store'}});}
 catch{return Response.json({error:'Memory is temporarily unavailable. Please try again.'},{status:503,headers:{'Cache-Control':'no-store'}});}
}
