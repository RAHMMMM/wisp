import { authorized } from '@/lib/auth';
import { liveConfigured } from '@/lib/config';
import { researchCycle } from '@/lib/agent';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export const maxDuration=120;
export async function POST(request:Request) {
 if(!authorized(request))return Response.json({error:'Unauthorized'},{status:401});
 if(!liveConfigured())return Response.json({error:'Live research is not configured. Check the server environment.'},{status:503});
 try{return Response.json(await researchCycle(),{headers:{'Cache-Control':'no-store'}});}
 catch(error){console.error('WISP research cycle failed:',error instanceof Error?error.name:'UnknownError');return Response.json({error:'Research could not complete. Check provider access and server configuration.'},{status:502});}
}
// Vercel Cron sends a GET with Authorization: Bearer CRON_SECRET.
export const GET=POST;
