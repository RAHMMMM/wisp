import { createClient, type Client } from '@libsql/client';
import { mkdir } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { liveConfigured, intervalMs } from './config';
import { demoSnapshot } from './demo';
import { edgesFor, type Memory, type Snapshot } from './types';
let client: Client | undefined;
let initialized: Promise<void> | undefined;
const firstQuestion='What is memory, and how does it help a system learn from experience?';
export async function database() {
 if(!client) {
  if(process.env.VERCEL && !process.env.TURSO_DATABASE_URL?.startsWith('libsql://')) throw new Error('Durable database required');
  if(!process.env.TURSO_DATABASE_URL) await mkdir('.data',{recursive:true});
  client=createClient({url:process.env.TURSO_DATABASE_URL||'file:.data/wisp.db',authToken:process.env.TURSO_AUTH_TOKEN});
 }
 const db=client;
 initialized??=(async()=>{await db.batch([
  `CREATE TABLE IF NOT EXISTS memories (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, summary TEXT NOT NULL, url TEXT NOT NULL UNIQUE, domain TEXT NOT NULL, timestamp TEXT NOT NULL, parent_id INTEGER REFERENCES memories(id), related_ids TEXT NOT NULL DEFAULT '[]', confidence REAL NOT NULL CHECK(confidence BETWEEN 0 AND 1), topic TEXT NOT NULL, question TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS sources (url TEXT PRIMARY KEY, visited_at TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS agent (id INTEGER PRIMARY KEY CHECK(id=1), born_at TEXT, thought TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'idle', updated_at TEXT NOT NULL, error TEXT, lease TEXT, lease_until INTEGER NOT NULL DEFAULT 0, next_run_at INTEGER NOT NULL DEFAULT 0)`,
  {sql:`INSERT OR IGNORE INTO agent(id, thought, updated_at) VALUES(1,?,?)`,args:[firstQuestion,new Date().toISOString()]}
 ],'write');})().catch(err=>{initialized=undefined;throw err;});
 await initialized;return db;
}
export async function getSnapshot():Promise<Snapshot> {
 if(!liveConfigured()) return demoSnapshot();
 const db=await database();
 const results=await db.batch(['SELECT * FROM memories ORDER BY id','SELECT * FROM agent WHERE id=1','SELECT COUNT(*) AS count FROM sources'],'read');
 const memories:Memory[]=results[0].rows.map(r=>({id:Number(r.id),title:String(r.title),summary:String(r.summary),url:String(r.url),domain:String(r.domain),timestamp:String(r.timestamp),parentId:r.parent_id===null?null:Number(r.parent_id),relatedIds:JSON.parse(String(r.related_ids)),confidence:Number(r.confidence),topic:String(r.topic),question:String(r.question)}));
 const a=results[1].rows[0];
 const stale=a.status==='researching'&&Number(a.lease_until)<Date.now();
 return {mode:'live',memories,edges:edgesFor(memories),thought:String(a.thought),status:stale?'error':a.status as Snapshot['status'],bornAt:a.born_at?String(a.born_at):null,updatedAt:String(a.updated_at),sourcesVisited:Number(results[2].rows[0].count),error:stale?'The last cycle was interrupted. The next trigger can retry.':a.error?String(a.error):null};
}
export async function acquireCycle() {
 const db=await database(),token=randomUUID(),now=Date.now();
 const result=await db.execute({sql:`UPDATE agent SET lease=?, lease_until=?, next_run_at=?, status='researching', error=NULL, born_at=COALESCE(born_at,?), updated_at=? WHERE id=1 AND lease_until<? AND next_run_at<=?`,args:[token,now+150_000,now+intervalMs(),new Date().toISOString(),new Date().toISOString(),now,now]});
 return result.rowsAffected===1?token:null;
}
export async function setThought(token:string,thought:string) {
 const db=await database();await db.execute({sql:'UPDATE agent SET thought=?, updated_at=? WHERE id=1 AND lease=?',args:[thought,new Date().toISOString(),token]});
}
export async function finishCycle(token:string, memory:Omit<Memory,'id'>|null, question:string, visited:string[]) {
 const db=await database(),tx=await db.transaction('write');
 try {
  const a=(await tx.execute({sql:'SELECT lease, lease_until FROM agent WHERE id=1',args:[]})).rows[0];
  if(a.lease!==token||Number(a.lease_until)<Date.now()) throw new Error('Research lease expired');
  let id:number|null=null;
  if(memory) {
   const result=await tx.execute({sql:'INSERT INTO memories(title,summary,url,domain,timestamp,parent_id,related_ids,confidence,topic,question) VALUES(?,?,?,?,?,?,?,?,?,?)',args:[memory.title,memory.summary,memory.url,memory.domain,memory.timestamp,memory.parentId,JSON.stringify(memory.relatedIds),memory.confidence,memory.topic,memory.question]});id=Number(result.lastInsertRowid);
  }
  for(const url of visited) await tx.execute({sql:'INSERT OR IGNORE INTO sources(url,visited_at) VALUES(?,?)',args:[url,new Date().toISOString()]});
  await tx.execute({sql:`UPDATE agent SET thought=?,status='idle',error=NULL,updated_at=?,lease=NULL,lease_until=0 WHERE id=1 AND lease=?`,args:[question,new Date().toISOString(),token]});
  await tx.commit();return id;
 } catch(err){await tx.rollback();throw err;} finally {tx.close();}
}
export async function failCycle(token:string) {
 const db=await database();await db.execute({sql:`UPDATE agent SET status='error', error=?, updated_at=?, lease=NULL, lease_until=0 WHERE id=1 AND lease=?`,args:['Research paused after a provider or validation error. The next scheduled cycle can retry.',new Date().toISOString(),token]});
}
