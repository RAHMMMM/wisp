import { edgesFor, type Memory, type Snapshot } from './types';
// Curated illustrative records. Never inserted into the live database.
const seeds: [string,string,string,number|null,number[],string][] = [
 ['A memory is a connection','Memory is not a single place. Experiences can be represented by changes across networks of neurons, with different systems supporting different kinds of recall.','https://www.ncbi.nlm.nih.gov/books/NBK10960/',null,[],'Memory'],
 ['The shape of forgetting','Forgetting is not simply a failure to remember. It can also reflect interference between memories and changes in how a memory is retrieved.','https://pmc.ncbi.nlm.nih.gov/articles/PMC5638094/',1,[],'Memory'],
 ['Neurons that fire together','Hebbian learning proposes that repeated, coordinated activity can strengthen the connection between neurons. Relationships change through experience.','https://en.wikipedia.org/wiki/Hebbian_theory',1,[],'Learning'],
 ['The internet has a structure','The web can be described as a graph: pages are nodes, hyperlinks are directed edges. Following one link is a small movement through that structure.','https://en.wikipedia.org/wiki/Webgraph',1,[],'Networks'],
 ['Small worlds, short paths','Some networks combine tightly connected neighborhoods with surprisingly short paths between distant nodes. Local clusters can coexist with global reach.','https://www.nature.com/articles/30918',4,[3],'Networks'],
 ['When a model forgets','Learning a new task can interfere with previously learned behavior in a neural network. This challenge is known as catastrophic forgetting.','https://www.pnas.org/doi/10.1073/pnas.1611835114',2,[3],'Learning'],
 ['Knowledge beyond a document','A knowledge graph represents entities and the relationships between them. It makes connections explicit rather than leaving them only inside text.','https://arxiv.org/abs/2003.02320',4,[1],'Networks'],
 ['Memory outside the model','Retrieval-augmented generation combines a language model with retrieved information. The model can consult material beyond the knowledge held in its parameters.','https://arxiv.org/abs/2005.11401',7,[6],'Intelligence'],
 ['Curiosity as a signal','An agent can use prediction error as an intrinsic reward. Unexpected observations may guide exploration even when external rewards are sparse.','https://arxiv.org/abs/1705.05363',3,[6],'Intelligence'],
 ['The strength of weak ties','Connections between otherwise separate social groups can carry information that close-knit groups do not already share. A bridge need not be a strong tie.','https://www.journals.uchicago.edu/doi/10.1086/225469',5,[7],'Networks'],
 ['A map is a compression','A useful representation leaves some details out. Information theory gives a mathematical language for studying compression and uncertainty.','https://en.wikipedia.org/wiki/Information_theory',7,[2],'Information'],
 ['Remembering changes a memory','Under some conditions, a retrieved memory can become vulnerable to change before it stabilizes again. Remembering is not always a passive read operation.','https://www.nature.com/articles/35021052',2,[6],'Memory'],
 ['Attention creates a context','Attention mechanisms weight relationships among elements in a sequence. Their relevance can change with the surrounding context.','https://arxiv.org/abs/1706.03762',8,[3,11],'Intelligence'],
 ['A path becomes a question','Open-ended learning studies systems that continue acquiring skills or knowledge instead of optimizing only a single fixed task. Exploration has no simple finishing line.','https://arxiv.org/abs/2406.04268',9,[8,10],'Intelligence'],
 ['What should a mind keep?','Continual learning explores how systems can acquire new knowledge while retaining useful previous knowledge. Retention and adaptation are competing demands.','https://arxiv.org/abs/1909.08383',6,[12,14],'Learning'],
 ['The edge of what is known','Uncertainty can help an agent decide what to investigate next. An unexplained connection can be more useful than another familiar answer.','https://en.wikipedia.org/wiki/Active_learning_(machine_learning)',14,[9,15],'Information'],
];
export const demoMemories: Memory[] = seeds.map((s,i)=>({
 id:i+1,title:s[0],summary:s[1],url:s[2],domain:new URL(s[2]).hostname.replace(/^www\./,''),
 timestamp:new Date(Date.UTC(2026,8,17,0,i*12)).toISOString(),parentId:s[3],relatedIds:s[4],
 confidence:[.92,.86,.95,.98,.94,.93,.96,.94,.88,.91,.93,.87,.96,.82,.91,.85][i],topic:s[5],
 question:i===15?'If artificial systems can develop persistent memory, how does forgetting change their behavior?':`What connects ${s[0].toLowerCase()} to persistent memory?`
}));
export function demoSnapshot(): Snapshot {
 return {mode:'demo',memories:demoMemories,edges:edgesFor(demoMemories),thought:demoMemories.at(-1)!.question,status:'demo',bornAt:null,updatedAt:demoMemories.at(-1)!.timestamp,sourcesVisited:0,error:null};
}
