import { z } from 'zod';
import { acquireCycle, failCycle, finishCycle, getSnapshot, setThought } from './store';
import { jsonCompletion, searchWeb, type SearchResult } from './providers';
import type { Memory } from './types';
const planSchema=z.object({question:z.string().min(10).max(350),parentId:z.number().int().positive().nullable()});
export const discoverySchema=z.object({novel:z.boolean(),title:z.string().max(120),summary:z.string().max(900),sourceIndex:z.number().int().min(0).max(3),evidence:z.string().max(700),confidence:z.number().min(0).max(1),relatedIds:z.array(z.number().int().positive()).max(4),topic:z.string().min(1).max(32),nextQuestion:z.string().min(10).max(350)});
type Discovery=z.infer<typeof discoverySchema>;
const normalize=(v:string)=>v.toLowerCase().replace(/[^a-z0-9\s]/g,'').replace(/\s+/g,' ').trim();
export function validateDiscovery(d:Discovery,results:SearchResult[],memories:Memory[]) {
 if(!d.novel)return null;
 const source=results[d.sourceIndex];
 if(!source)throw new Error('Unknown source');
 if(d.title.trim().length<5||d.summary.trim().length<40||d.evidence.trim().length<24)throw new Error('Insufficient evidence');
 const clean=(s:string)=>s.replace(/\s+/g,' ').trim().toLowerCase();
 if(!clean(source.text).includes(clean(d.evidence)))throw new Error('Evidence not found in source');
 if(memories.some(m=>m.url===source.url||normalize(m.title)===normalize(d.title)))return null;
 return source;
}
export async function researchCycle() {
 const token=await acquireCycle();if(!token)return {status:'skipped',reason:'A cycle is running or the minimum interval has not elapsed.'};
 try {
  const signal=AbortSignal.timeout(85_000),snapshot=await getSnapshot();
  if(snapshot.memories.length>=1000)throw new Error('Launch memory limit reached');
  const recent=snapshot.memories.slice(-80).map(m=>({id:m.id,title:m.title,summary:m.summary,question:m.question}));
  const plan=await jsonCompletion('You are Wisp, a careful internet research agent. Choose one specific, unresolved factual question that follows from the existing memories or current thought. If there are no memories, begin with the current thought. Choose parentId from the provided memories, or null only if memory is empty. Return {"question":string,"parentId":number|null}.', {currentThought:snapshot.thought,memories:recent},planSchema,signal);
  if(snapshot.memories.length ? !snapshot.memories.some(m=>m.id===plan.parentId) : plan.parentId!==null)throw new Error('Invalid parent memory');
  await setThought(token,plan.question);
  const results=await searchWeb(plan.question,signal);
  if(!results.length)throw new Error('No readable source material');
  const discovery=await jsonCompletion('Read these source excerpts and extract ONE genuinely new, supported discovery relative to the existing knowledge. Prefer primary sources. Do not infer claims the source does not establish. novel must be false if there is no new reliable fact, or if the source URL is already known. Provide a short title, a plain-language summary, sourceIndex (zero-based), an exact evidence quote copied from that excerpt, a conservative confidence estimate (0–1, not a measured probability), up to four relatedIds from existing memories, a short topic, and nextQuestion arising from this discovery. Return {"novel":boolean,"title":string,"summary":string,"sourceIndex":number,"evidence":string,"confidence":number,"relatedIds":number[],"topic":string,"nextQuestion":string}. For no novelty, use empty title, summary, evidence and sourceIndex 0, but still provide a useful nextQuestion.',{question:plan.question,existing:recent,knownSources:snapshot.memories.map(m=>({title:m.title,url:m.url})),sources:results},discoverySchema,signal);
  const source=validateDiscovery(discovery,results,snapshot.memories);
  const ids=new Set(snapshot.memories.map(m=>m.id));
  const memory:Omit<Memory,'id'>|null=source?{title:discovery.title.trim(),summary:discovery.summary.trim(),url:source.url,domain:new URL(source.url).hostname.replace(/^www\./,''),timestamp:new Date().toISOString(),parentId:plan.parentId,relatedIds:[...new Set(discovery.relatedIds)].filter(id=>ids.has(id)&&id!==plan.parentId),confidence:Math.min(.95,discovery.confidence),topic:discovery.topic,question:discovery.nextQuestion}:null;
  const id=await finishCycle(token,memory,discovery.nextQuestion,results.map(r=>r.url));
  return {status:memory?'discovered':'no-new-discovery',memoryId:id};
 }catch(error){await failCycle(token);throw error;}
}
