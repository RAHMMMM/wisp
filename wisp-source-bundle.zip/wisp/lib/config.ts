export function liveConfigured() {
 const e = process.env;
 return e.WISP_MODE !== 'demo' && !!(e.LLM_API_KEY && e.LLM_MODEL && e.TAVILY_API_KEY && e.CRON_SECRET && e.CRON_SECRET.length >= 32)
   && (!e.VERCEL || !!(e.TURSO_DATABASE_URL?.startsWith('libsql://') && e.TURSO_AUTH_TOKEN));
}
export function intervalMs() {
 const n = Number(process.env.RESEARCH_INTERVAL_MINUTES || 10);
 return Math.max(1, Number.isFinite(n) ? n : 10) * 60_000;
}
