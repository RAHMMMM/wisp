export type Memory = {
  id: number; title: string; summary: string; url: string; domain: string;
  timestamp: string; parentId: number | null; relatedIds: number[];
  confidence: number; topic: string; question: string;
};
export type Edge = { source: number; target: number; kind: 'path' | 'related' };
export type Snapshot = {
  mode: 'demo' | 'live'; memories: Memory[]; edges: Edge[];
  thought: string; status: 'demo' | 'idle' | 'researching' | 'error';
  bornAt: string | null; updatedAt: string; sourcesVisited: number;
  error: string | null;
};
export function edgesFor(memories: Memory[]): Edge[] {
  const ids = new Set(memories.map(m => m.id));
  const edges = new Map<string, Edge>();
  for (const m of memories) {
    for (const id of [m.parentId, ...m.relatedIds]) {
      if (id === null || id === m.id || !ids.has(id)) continue;
      const key = [id, m.id].sort((a,b) => a-b).join('-');
      const kind = id === m.parentId ? 'path' : 'related';
      if (!edges.has(key) || kind === 'path') edges.set(key, {source:id,target:m.id,kind});
    }
  }
  return [...edges.values()];
}
