# WISP

**An agent with an empty memory.** A quiet, interactive observatory for an evolving knowledge graph. Wisp is not a chatbot.

## Run it

Requires Node.js 22 or newer.

```sh
npm ci
cp .env.example .env.local
npm run dev
```

Open http://127.0.0.1:3000. No keys are needed for the polished demo. Select a graph node or a recent memory to inspect its source, parent, related memories, timestamp, and confidence. Drag the field, use the zoom controls, and pause motion. Keyboard users can tab to nodes and press Enter; Escape closes the detail panel. Reduced-motion preferences are respected.

## Demo is not live research

Without the required configuration, Wisp clearly displays **DEMO MODE**. Its 16 seed memories are hand-curated, illustrative examples. Their timestamps and confidence values are illustrative. They are never written into the live database. The demo does not call search or LLM providers, does not invent source visits or age, and does not simulate discoveries arriving over time. Motion is visual only.

The live database starts empty. The first successful trigger creates its first discovery. Merely visiting the website never starts paid research. `WISP_MODE=demo` forces demo mode even when credentials exist. Invalid credentials do not cause fallback to demo: the live interface reports a paused/error state instead.

## Enable real research

Set these **server-side** variables in `.env.local` or your deployment environment:

| Variable | Purpose |
| --- | --- |
| `LLM_API_KEY` | Key for an OpenAI-compatible Chat Completions provider |
| `LLM_MODEL` | A model available to your account, supporting JSON mode and `max_completion_tokens` |
| `LLM_BASE_URL` | Defaults to `https://api.openai.com/v1`; HTTPS required |
| `TAVILY_API_KEY` | Tavily search with extracted page text |
| `SEARCH_PROVIDER` | `tavily`; currently the only implemented search adapter |
| `CRON_SECRET` | A random secret of at least 32 characters |
| `RESEARCH_INTERVAL_MINUTES` | Minimum gap between starts; default 10 minutes |
| `TURSO_DATABASE_URL` | Remote `libsql://…` URL; required on Vercel |
| `TURSO_AUTH_TOKEN` | Remote database token; required on Vercel |
| `WISP_MODE` | `auto` (default) or `demo` |

Generate a trigger secret with `openssl rand -hex 32`. Never use a `NEXT_PUBLIC_` prefix for secrets. `.env.local` and the local database are ignored by Git.

Local live operation uses `.data/wisp.db` when no Turso URL is set. This is a real SQLite database and survives app restarts. Turso uses the same schema and client over HTTP. Tables initialize automatically; no migration CLI or background server is necessary. Back up the SQLite file or use your database provider's backup facilities before replacing a database. Changing database URLs does not migrate existing records.

## Trigger one research cycle

Use your secret from a trusted terminal or scheduler, never from client code:

```sh
curl --request POST https://YOUR-DOMAIN/api/research \
  --header "Authorization: Bearer $CRON_SECRET"
```

For local development, replace the URL with `http://127.0.0.1:3000/api/research`. The shell variable must contain the same secret as the server environment. Next.js loads `.env.local`; your shell does not load it automatically.

A bounded cycle:

1. Acquires a database-backed lease and checks the minimum interval.
2. Reads saved memories and the current unresolved question.
3. Asks the configured model to select a question and a valid parent memory.
4. Searches through Tavily and reads up to four extracted source excerpts.
5. Asks the model for one novel, source-grounded discovery and its next question.
6. Validates structured output, source membership, a verbatim evidence excerpt, duplicate URL/title checks, parent and related IDs.
7. Atomically saves the memory, source visits, links, next question, and status.

Two model calls and one search per cycle; no recursive browsing, vector database, queue, or agent framework. Search result snippets alone are not treated as read articles. Results without extracted page text are skipped. Source visits count unique normalized URLs whose excerpts were processed in completed cycles, including cycles that find nothing new.

The 150-second lease prevents simultaneous writers and recovers after interrupted requests. External work has an 85-second shared timeout; the Vercel function allows 120 seconds. Failed cycles retain previous memories, show a safe error, and can retry after the interval. Successful cycles with no new evidence save no memory but advance the question. GET and POST share the same protected route for Vercel Cron compatibility. Unauthorized requests return 401; incomplete configuration returns 503; provider/validation failures return 502.

Confidence is a model estimate, capped at 95%, **not a calibrated probability or independent verification**. The evidence check and novelty prompt reduce unsupported or redundant entries but cannot guarantee truth or semantic uniqueness. Content is rendered as plain text. The model cannot select arbitrary output URLs: stored URLs come from the search results. The app never directly fetches model-generated or visitor-supplied URLs.

To keep this launch implementation bounded, research stops at 1,000 memories. The graph displays all saved records; the reasoning context uses the latest 80 full memories plus all known titles and URLs. Raise this limit only alongside graph and retrieval changes.

## Deploy to Vercel

1. Put this directory in a Git repository and import it into Vercel as a **Next.js** project. Set the Root Directory to this folder if importing a larger repository.
2. Use Node.js 22 or newer. The build command is `npm run build`, install command `npm ci`. No static export is used: API routes need the server runtime.
3. You can deploy with no credentials for a clearly labeled demo.
4. For live mode, create a Turso database and add its `libsql://` URL and token, the LLM variables, Tavily key, and `CRON_SECRET` in Vercel's production environment. Redeploy after changing variables. Vercel filesystems are ephemeral; local SQLite is deliberately disallowed there.
5. `vercel.json` includes one daily research trigger at **08:00 UTC**. Vercel injects `Authorization: Bearer CRON_SECRET` when configured. Confirm cron support and timing for your plan. Use a separate database for preview deployments to avoid modifying production memories.
6. Trigger the first cycle manually, check `/api/memories`, and confirm a live memory appears. Refresh the page to verify persistence. The interface polls every 15 seconds while visible.
7. To explore more often, adjust the cron schedule to your plan's supported frequency. Set provider spending limits. The database interval still prevents overlapping or excessively frequent starts.

Do not put secrets in `vercel.json`, commit them, or expose a research button with a secret in the browser. There are intentionally no user accounts, payments, or administrative UI. Anyone can read published memories; only an authorized trigger can cause paid research.

## Verify

```sh
npm run typecheck
npm test
npm run build
npm start
```

Tests exercise demo labeling, endpoint authorization, URL filtering, evidence validation, real SQLite persistence through a second connection, the research loop with **mock providers**, cooldown, concurrent lease acquisition, and error recovery. Mock tests do not prove real API access; a paid live cycle requires your credentials.

## Files

- `components/observatory.tsx` — homepage, live polling, accessible memory inspector.
- `components/memory-graph.tsx` — lightweight SVG graph with drift, entry animation, pan, zoom, and keyboard selection.
- `lib/agent.ts` — bounded research cycle and discovery validation.
- `lib/providers.ts` — server-side LLM and search adapters.
- `lib/store.ts` — SQLite/Turso persistence, transactional writes, and lease.
- `lib/demo.ts` — isolated, explicitly illustrative seed records.
- `app/api/research/route.ts` — protected manual/cron trigger.
- `app/api/memories/route.ts` — public read-only snapshot.

## Hosted demo preview

`npm run build:demo` creates a static export in `out/` using a tiny entry point in `preview/`. It imports the same interface and explicit demo seeds as the full app. This export has **no server endpoints or live research**; it is suitable for the hosted Sites preview. `.openai/hosting.json` applies only to this demo export. The ordinary `npm run build` and Vercel deployment use the complete live-capable Next.js app. Do not deploy `out/` expecting the agent to run.

## Provider references

Implementation follows [OpenAI JSON mode](https://developers.openai.com/api/docs/guides/structured-outputs), [Tavily Search](https://docs.tavily.com/documentation/api-reference/endpoint/search), and the [Turso TypeScript client](https://docs.turso.tech/sdk/ts/reference). JSON output is validated with Zod rather than assumed correct. Alternative OpenAI-compatible providers may differ; verify their model and parameter support before launch.
