import Observatory from '../../components/observatory';
import { demoSnapshot } from '../../lib/demo';
export default function Preview() { return <Observatory initial={demoSnapshot()} />; }
