import path from 'node:path';
export default {output:'export', poweredByHeader:false, turbopack:{root:path.resolve(__dirname,'..')}};
