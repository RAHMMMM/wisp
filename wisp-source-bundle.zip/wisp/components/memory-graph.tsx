'use client';
import { useEffect, useRef, useState } from 'react';
import { Minus, Plus, Maximize2, Pause, Play } from 'lucide-react';
import type { Memory, Edge } from '@/lib/types';
const anchors = [[570,267],[412,205],[609,145],[735,306],[850,240],[422,329],[713,180],[585,375],[496,110],[906,351],[792,112],[283,256],[700,419],[365,115],[303,382],[497,437]];
function position(i:number) {
 if(i < anchors.length) return {x:anchors[i][0],y:anchors[i][1]};
 const a=i*2.399963, r=100+Math.sqrt(i)*28;
 return {x:600+Math.cos(a)*Math.min(r,475),y:275+Math.sin(a)*Math.min(r*.58,210)};
}
export default function MemoryGraph({memories,edges,onSelect,selectedId}:{memories:Memory[];edges:Edge[];onSelect:(m:Memory)=>void;selectedId:number|null}) {
 const svg=useRef<SVGSVGElement>(null), layer=useRef<SVGGElement>(null);
 const [paused,setPaused]=useState(false),[view,setView]=useState({x:0,y:0,k:1});
 const drag=useRef<{x:number;y:number;ox:number;oy:number; moved:boolean}|null>(null);
 const clickSuppressed=useRef(false);
 const [hovered,setHovered]=useState<number|null>(null);
 useEffect(()=>{
  const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let frame=0; const start=performance.now();
  function draw(now:number) {
   const t=paused||reduced?0:(now-start)/1000;
   const points=new Map(memories.map((m,i)=>{const p=position(i);return [m.id,{x:p.x+Math.sin(t*.23+i*1.9)*8,y:p.y+Math.cos(t*.19+i*1.3)*7}]}));
   for(const m of memories) {const p=points.get(m.id)!; const el=svg.current?.querySelector(`[data-node="${m.id}"]`);el?.setAttribute('transform',`translate(${p.x} ${p.y})`);}
   for(const edge of edges) {const a=points.get(edge.source),b=points.get(edge.target);if(!a||!b)continue;const el=svg.current?.querySelector(`[data-edge="${edge.source}-${edge.target}"]`);el?.setAttribute('d',`M ${a.x} ${a.y} Q ${(a.x+b.x)/2+12} ${(a.y+b.y)/2-15} ${b.x} ${b.y}`);}
   if(!paused&&!reduced) frame=requestAnimationFrame(draw);
  }
  draw(start); return()=>cancelAnimationFrame(frame);
 },[memories,edges,paused]);
 const active=hovered??selectedId;
 const neighbors=new Set(edges.filter(e=>e.source===active||e.target===active).flatMap(e=>[e.source,e.target]));
 const zoom=(delta:number)=>setView(v=>({...v,k:Math.max(.65,Math.min(2.4,v.k+delta))}));
 return <div className="graph-surface">
  <div className="graph-coordinate top-left">THE MEMORY FIELD <span>/ {String(memories.length).padStart(3,'0')} NODES</span></div>
  <div className="graph-coordinate top-right"><span className="crosshair">+</span> EACH POINT, A DISCOVERY</div>
  <svg ref={svg} className="memory-svg" viewBox="150 30 900 500" aria-label="Interactive knowledge graph. Select a memory to read its source." onPointerDown={e=>{clickSuppressed.current=false;if((e.target as Element).closest('[data-node]'))return;e.currentTarget.setPointerCapture(e.pointerId);drag.current={x:e.clientX,y:e.clientY,ox:view.x,oy:view.y,moved:false};clickSuppressed.current=false;}} onPointerMove={e=>{const d=drag.current;if(!d)return;const rect=e.currentTarget.getBoundingClientRect();const scale=Math.max(900/rect.width,500/rect.height);d.moved ||= Math.abs(e.clientX-d.x)+Math.abs(e.clientY-d.y)>5;setView(v=>({...v,x:d.ox+(e.clientX-d.x)*scale,y:d.oy+(e.clientY-d.y)*scale}));}} onPointerUp={()=>{clickSuppressed.current=!!drag.current?.moved;drag.current=null;}} onPointerCancel={()=>{drag.current=null;}}>
   <defs>
    <radialGradient id="field-glow"><stop stopColor="#afdadb" stopOpacity=".065"/><stop offset="1" stopColor="#afdadb" stopOpacity="0"/></radialGradient>
    <radialGradient id="node-glow"><stop stopColor="#efffff" stopOpacity=".6"/><stop offset=".17" stopColor="#d9ffff" stopOpacity=".19"/><stop offset="1" stopColor="#addfe4" stopOpacity="0"/></radialGradient>
    <pattern id="grid-dots" width="30" height="30" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r=".6" fill="#8ca3a3" opacity=".16"/></pattern>
   </defs>
   <rect width="1200" height="550" fill="url(#grid-dots)"/>
   <ellipse cx="590" cy="285" rx="470" ry="270" fill="url(#field-glow)"/>
   <g ref={layer} transform={`translate(${600+view.x} ${275+view.y}) scale(${view.k}) translate(-600 -275)`}>
    {edges.map(e=>{const a=position(memories.findIndex(m=>m.id===e.source)),b=position(memories.findIndex(m=>m.id===e.target));return <path key={`${e.source}-${e.target}`} data-edge={`${e.source}-${e.target}`} d={`M${a.x} ${a.y}L${b.x} ${b.y}`} fill="none" stroke={active&&(e.source===active||e.target===active)?'#a5d8db':'#547075'} strokeWidth={e.kind==='path'?.85:.6} opacity={active?(e.source===active||e.target===active?.85:.12):e.kind==='path'?.5:.27} strokeDasharray={e.kind==='related'?'2 5':undefined}/>;})}
    {memories.map((m,i)=>{const p=position(i), focus=m.id===active, faded=active!==null&&!focus&&!neighbors.has(m.id);return <g key={m.id} data-node={m.id} transform={`translate(${p.x} ${p.y})`} tabIndex={0} role="button" aria-label={`Memory ${m.id}: ${m.title}`} className={`graph-node ${focus?'active':''}`} style={{opacity:faded?.25:1}} onMouseEnter={()=>setHovered(m.id)} onMouseLeave={()=>setHovered(null)} onFocus={()=>setHovered(m.id)} onBlur={()=>setHovered(null)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();onSelect(m);}}} onClick={()=>{if(!clickSuppressed.current)onSelect(m);}}>
     <g className="node-emerge" style={{animationDelay:`${Math.min(i*65,950)}ms`}}>
      <circle r={focus?39:i===0?37:26} fill="url(#node-glow)" className={paused?'':'node-aura'} style={{animationDelay:`${i*.41}s`}}/>
      <circle r="19" fill="transparent"/>
      <circle r={focus?11:i===0?9:5.5} fill="none" stroke="#d0e8ea" strokeWidth=".65" opacity={focus?.8:.2}/>
      <circle r={i===0?3.6:2.6} fill={focus?'#fff':'#dceff0'}/>
      {(i===0||focus)&&<path d="M-15 0H-8M8 0H15M0-15V-8M0 8V15" stroke="#d5f0f2" strokeWidth=".5" opacity=".6"/>}
      {(focus||[0,1,3,5,7,9,12,15].includes(i))&&<text x="0" y="-23" textAnchor="middle" className={`node-label ${focus?'focused-label':''}`} fill={focus?'#f0f6f6':'#90a3a6'}>{m.title}</text>}
      {(i===0||focus)&&<text x="0" y="31" textAnchor="middle" className="node-number">MEMORY {String(m.id).padStart(3,'0')}</text>}
     </g>
    </g>})}
   </g>
  </svg>
  {!memories.length&&<div className="empty-graph"><span className="empty-spark"/><h3>Nothing remembered. Everything ahead.</h3><p>The first research cycle will create Wisp’s first memory.</p></div>}
  <div className="graph-coordinate bottom-left"><span className="legend-dot"/> MEMORY <span className="legend-line"/> CONNECTION</div>
  <div className="graph-controls"><button title={paused?'Resume motion':'Pause motion'} aria-label={paused?'Resume motion':'Pause motion'} onClick={()=>setPaused(!paused)}>{paused?<Play size={14}/>:<Pause size={14}/>}</button><span/><button aria-label="Zoom out" title="Zoom out" onClick={()=>zoom(-.2)}><Minus size={15}/></button><button aria-label="Zoom in" title="Zoom in" onClick={()=>zoom(.2)}><Plus size={15}/></button><button aria-label="Reset graph view" title="Reset view" onClick={()=>setView({x:0,y:0,k:1})}><Maximize2 size={14}/></button></div>
 </div>
}
