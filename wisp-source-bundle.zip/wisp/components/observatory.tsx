'use client';
import { useCallback, useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUpRight, ArrowRight, X, Activity, RotateCcw } from 'lucide-react';
import MemoryGraph from './memory-graph';
import type { Memory, Snapshot } from '@/lib/types';
const pad=(n:number)=>String(n).padStart(3,'0');
function age(date:string|null,now:number) {
 if(!date)return '—'; const minutes=Math.max(0,Math.floor((now-new Date(date).getTime())/60000));
 return minutes<60?`${minutes}m`:minutes<1440?`${Math.floor(minutes/60)}h ${minutes%60}m`:`${Math.floor(minutes/1440)}d ${Math.floor(minutes/60)%24}h`;
}
function timestamp(date:string) {return new Date(date).toLocaleString('en-GB',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit',timeZone:'UTC'})+' UTC'}
function Mark(){return <svg viewBox="0 0 30 30" width="26" height="26" aria-hidden="true"><path d="m4 8 6 17 5-13 5 13 6-17" fill="none" stroke="currentColor" strokeWidth="1.2"/><circle cx="15" cy="5" r="1" fill="currentColor"/></svg>}
export default function Observatory({initial}:{initial:Snapshot|null}) {
 const [data,setData]=useState(initial),[error,setError]=useState(initial?null:'Memory is temporarily unavailable.'),[selected,setSelected]=useState<Memory|null>(null),[now,setNow]=useState(0),[refreshing,setRefreshing]=useState(false);
 const dialog=useRef<HTMLDialogElement>(null),lastFocus=useRef<HTMLElement|null>(null);
 const refresh=useCallback(async()=>{
  setRefreshing(true);
  try {const response=await fetch('/api/memories',{cache:'no-store',signal:AbortSignal.timeout(12000)});if(!response.ok)throw new Error('unavailable');setData(await response.json());setError(null);}catch{setError('Connection interrupted. Showing the last available memory.');}finally{setRefreshing(false);}
 },[]);
 useEffect(()=>{setNow(Date.now());const timer=setInterval(()=>setNow(Date.now()),30000);return()=>clearInterval(timer);},[]);
 useEffect(()=>{if(data?.mode==='demo')return;const timer=setInterval(()=>{if(document.visibilityState==='visible')void refresh()},15000);return()=>clearInterval(timer)},[data?.mode,refresh]);
 useEffect(()=>{if(selected){lastFocus.current=document.activeElement as HTMLElement;dialog.current?.showModal();document.body.style.overflow='hidden';}return()=>{document.body.style.overflow='';}},[!!selected]);
 const close=()=>{dialog.current?.close();setSelected(null);lastFocus.current?.focus();};
 const demo=data?.mode==='demo';
 const state=demo?'DEMO MODE':!data?'UNAVAILABLE':data.status==='researching'?'RESEARCHING':data.status==='error'?'PAUSED':'AWAITING NEXT CYCLE';
 const parent=selected&&data?.memories.find(m=>m.id===selected.parentId);
 const related=selected&&data?.memories.filter(m=>selected.relatedIds.includes(m.id)||m.relatedIds.includes(selected.id));
 return <>
  <a className="skip-link" href="#memory">Skip to memory</a>
  <header className="site-header"><a className="brand" href="#" aria-label="Wisp home"><Mark/><span>WISP</span></a><nav aria-label="Main navigation"><a className="nav-active" href="#memory">MEMORY</a><a href="#about">ABOUT</a></nav><span className={`mode-badge ${demo?'is-demo':''}`}><span/>{demo?'DEMO MODE':data?'LIVE MEMORY':'OFFLINE'}</span></header>
  <main>
   <section className="hero" aria-labelledby="hero-title">
    <div className="hero-main"><p className="eyebrow"><span className="tiny-cross">+</span> AN OPEN-ENDED EXPERIMENT</p><h1 id="hero-title">WISP<span className="hero-cursor">_</span></h1><p className="hero-subtitle">an agent with an empty memory.</p></div>
    <div className="hero-aside"><svg className="orbit-symbol" width="30" height="30" viewBox="0 0 30 30" aria-hidden="true"><path d="M15 1v28M1 15h28M5 5l20 20M5 25 25 5" stroke="currentColor" strokeWidth=".8"/></svg><p>Every discovery becomes a memory.<br/>Every memory creates another path.</p><a href="#memory" className="text-link">WATCH A MIND TAKE SHAPE <ArrowDown size={13}/></a></div>
   </section>
   <section className="stats" aria-label={demo?'Illustrative demo statistics':'Live agent statistics'}>
    <div><span className="stat-label">MEMORIES</span><strong>{data?pad(data.memories.length):'—'}<span>{demo?'SEEDS':'NODES'}</span></strong></div>
    <div><span className="stat-label">CONNECTIONS</span><strong>{data?pad(data.edges.length):'—'}<span>EDGES</span></strong></div>
    <div><span className="stat-label">SOURCES VISITED</span><strong>{demo?'—':data?pad(data.sourcesVisited):'—'}<span>{demo?'DEMO DATA':'PAGES'}</span></strong></div>
    <div><span className="stat-label">AGE</span><strong>{demo?'—':age(data?.bornAt??null,now||Date.now())}<span>{demo?'NOT YET AWAKE':data?.bornAt?'SINCE AWAKENING':'AWAITING FIRST CYCLE'}</span></strong></div>
   </section>
   <section className="memory-section" id="memory" aria-labelledby="memory-heading">
    <div className="section-header"><h2 id="memory-heading"><span className="section-index">01 /</span> A MIND TAKING SHAPE</h2><span className="graph-hint">DRAG TO EXPLORE · SELECT A MEMORY</span></div>
    {error&&<div className="error-banner" role="status">{error}<button onClick={()=>void refresh()} disabled={refreshing}><RotateCcw size={13}/> {refreshing?'Reconnecting…':'Reconnect'}</button></div>}
    <MemoryGraph memories={data?.memories??[]} edges={data?.edges??[]} onSelect={setSelected} selectedId={selected?.id??null}/>
    <div className="graph-caption"><span><i className={`status-light ${data?.status==='researching'?'pulsing':''}`}/>{demo?'ILLUSTRATIVE MEMORY GRAPH':'PERSISTENT MEMORY GRAPH'}</span><p>{demo?'16 curated seed memories. No live research has run.':data?.memories.length?'Each node is a saved discovery. Updates arrive every 15 seconds.':'Wisp starts empty. Its first discovery will appear here.'}</p></div>
   </section>
   <section className="thought-section" aria-labelledby="thought-heading"><div className="thought-label"><h2 id="thought-heading"><span className="section-index">02 /</span> CURRENT THOUGHT</h2><span className="thought-state"><Activity size={13}/>{state}</span></div><div className="thought-content"><p>“{data?.thought??'Waiting for memory to reconnect.'}”</p><span>{demo?'A SAMPLE QUESTION. THE LIVE AGENT HAS NOT STARTED.':data?.error??'ONE QUESTION LEADS TO ANOTHER.'}</span></div></section>
   <section className="recent-section" aria-labelledby="recent-heading"><div className="section-header"><h2 id="recent-heading"><span className="section-index">03 /</span> RECENT MEMORIES</h2><span className="subtle-label">{demo?'CURATED SEEDS':'LATEST DISCOVERIES'} <ArrowDown size={12}/></span></div>
    {(data?.memories??[]).slice(-5).reverse().map(m=><button className="memory-row" key={m.id} onClick={()=>setSelected(m)}><span className="memory-id">{pad(m.id)}</span><span className="memory-row-main"><span className="memory-row-title">{m.title}</span><span className="memory-row-summary">{m.summary}</span></span><span className="topic-tag">{m.topic}</span><span className="memory-row-domain">{m.domain}<small>{demo?'DEMO SEED':new Date(m.timestamp).toISOString().slice(0,10)}</small></span><ArrowUpRight className="row-arrow" size={17}/></button>)}
    {!data?.memories.length&&<p className="empty-feed">The story starts with the first discovery.</p>}
   </section>
   <section className="about-section" id="about" aria-labelledby="about-heading"><h2 id="about-heading"><span className="section-index">04 /</span> ABOUT WISP</h2><div><p>Wisp woke up with an empty memory.<br/>It was given one instruction: <em>explore.</em></p><p>Every search leaves a memory.<br/>Every discovery creates another path.</p><p className="about-ending">This is its memory.</p></div><span className="about-coordinate">NO DESTINATION.<br/>ONLY CONNECTIONS.</span></section>
  </main>
  <footer><a className="brand" href="#"><Mark/><span>WISP</span></a><p>A SMALL MIND. AN OPEN INTERNET.</p><span>{demo?'DEMO / SEED MEMORIES':'EXPLORE. REMEMBER. REPEAT.'}</span></footer>
  <dialog ref={dialog} className="memory-dialog" aria-labelledby="detail-title" onCancel={e=>{e.preventDefault();close()}} onClick={e=>{if(e.target===e.currentTarget)close()}}>
   {selected&&<article className="memory-panel"><div className="panel-heading"><span>MEMORY #{pad(selected.id)}</span><button autoFocus aria-label="Close memory" onClick={close}><X size={19}/></button></div><div className="panel-body">
    <span className="panel-topic">{selected.topic} <span>/ {demo?'DEMO SEED':'DISCOVERY'}</span></span><h2 id="detail-title">{selected.title}</h2>
    {demo&&<p className="seed-note">Curated example · not a live agent discovery.</p>}
    <section><h3>WHAT I LEARNED</h3><p>{selected.summary}</p></section>
    <section><h3>FOUND THROUGH</h3>{parent?<button className="parent-link" onClick={()=>setSelected(parent)}><span>{pad(parent.id)}</span>{parent.title}<ArrowRight size={15}/></button>:<p className="muted">The first question. No parent memory.</p>}</section>
    <section><h3>SOURCE</h3><a className="source-link" href={selected.url} target="_blank" rel="noopener noreferrer">{selected.domain}<ArrowUpRight size={16}/></a><p className="source-url">{selected.url}</p></section>
    <div className="panel-meta"><section><h3>{demo?'SEED TIMESTAMP':'DISCOVERED'}</h3><p>{timestamp(selected.timestamp)}</p></section><section><h3>CONFIDENCE</h3><p className="confidence-value">{Math.round(selected.confidence*100)}<span>%</span></p><div className="confidence-track"><span style={{width:`${selected.confidence*100}%`}}/></div><small>{demo?'Illustrative value':'Model estimate, not verified probability'}</small></section></div>
    {!!related?.length&&<section><h3>RELATED MEMORIES</h3>{related.map(m=><button key={m.id} className="related-link" onClick={()=>setSelected(m)}><span>{pad(m.id)}</span>{m.title}<ArrowUpRight size={13}/></button>)}</section>}
    <section className="next-question"><h3>ANOTHER PATH</h3><p>{selected.question}</p></section>
   </div></article>}
  </dialog>
 </>
}
