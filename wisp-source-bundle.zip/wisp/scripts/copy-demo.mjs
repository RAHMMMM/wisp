import { cp, rm } from 'node:fs/promises';
await rm('out', {recursive:true,force:true});
await cp('preview/out','out',{recursive:true});
